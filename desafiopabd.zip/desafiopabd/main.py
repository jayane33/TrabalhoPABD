from frontend.telalogin import Aplication
Aplication()