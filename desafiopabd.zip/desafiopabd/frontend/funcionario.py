import tkinter as tk
from tkinter import messagebox, simpledialog

class Funcionario:
    def __init__(self, nome, cargo):
        self.nome = nome
        self.cargo = cargo

class FuncionarioInterface:
    def __init__(self, master):
        self.master = master
        self.master.title("Cadastro de Funcionário")
        self.master.geometry("400x300")
        self.master.configure(bg="lightpink")
        self.funcionarios = []

        self.criar_widgets()

    def criar_widgets(self):
        titulo = tk.Label(self.master, text="Cadastro de Funcionário", font=("Georgia", 18, "bold"), bg="lightpink")
        titulo.pack(pady=10)

        self.label_nome = tk.Label(self.master, text="Nome:", bg="lightpink")
        self.label_nome.pack(pady=5)
        self.entry_nome = tk.Entry(self.master, width=30)
        self.entry_nome.pack(pady=5)

        self.label_cargo = tk.Label(self.master, text="Cargo:", bg="lightpink")
        self.label_cargo.pack(pady=5)
        self.entry_cargo = tk.Entry(self.master, width=30)
        self.entry_cargo.pack(pady=5)

        self.botao_enviar = tk.Button(self.master, text="Cadastrar Funcionário", command=self.cadastrar_funcionario, bg="pink")
        self.botao_enviar.pack(pady=10)

        self.botao_listar = tk.Button(self.master, text="Listar Funcionários", command=self.listar_funcionarios, bg="pink")
        self.botao_listar.pack(pady=5)

        self.botao_deletar = tk.Button(self.master, text="Deletar Funcionário", command=self.deletar_funcionario, bg="lightcoral")
        self.botao_deletar.pack(pady=5)

    def cadastrar_funcionario(self):
        nome = self.entry_nome.get()
        cargo = self.entry_cargo.get()

        if nome and cargo:
            self.funcionarios.append(Funcionario(nome, cargo))
            messagebox.showinfo("Sucesso", f"Funcionário {nome} cadastrado com sucesso como {cargo}.")
            self.entry_nome.delete(0, tk.END)
            self.entry_cargo.delete(0, tk.END)
        else:
            messagebox.showwarning("Atenção", "Por favor, preencha todos os campos.")

    def listar_funcionarios(self):
        if not self.funcionarios:
            messagebox.showinfo("Funcionários", "Nenhum funcionário cadastrado.")
            return
        lista = "\n".join(f"{i+1}. {f.nome} - {f.cargo}" for i, f in enumerate(self.funcionarios))
        messagebox.showinfo("Funcionários Cadastrados", lista)

    def deletar_funcionario(self):
        nome = simpledialog.askstring("Deletar Funcionário", "Informe o nome do funcionário a ser deletado:")
        for f in self.funcionarios:
            if f.nome == nome:
                self.funcionarios.remove(f)
                messagebox.showinfo("Sucesso", f"Funcionário {nome} deletado.")
                return
        messagebox.showwarning("Atenção", "Funcionário não encontrado.")

if __name__ == "__main__":
    root = tk.Tk()
    app = FuncionarioInterface(root)
    root.mainloop()

