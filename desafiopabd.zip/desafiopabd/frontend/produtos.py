import tkinter as tk
from tkinter import ttk, simpledialog, messagebox

class Produto:
    def __init__(self, id_prod, nome_prod, descricao):
        self.id_prod = id_prod
        self.nome_prod = nome_prod
        self.descricao = descricao

class ProdutosInterface:
    def __init__(self, master):
        self.master = master
        self.master.title("CRUD de Produtos")
        self.master.geometry("600x400")
        self.master.configure(bg="lightpink")

        self.produtos = []
        self.criar_widgets()

    def criar_widgets(self):
        titulo = tk.Label(self.master, text="Tabela de Produtos Cadastrados", font=("Georgia", 18), bg="lightpink")
        titulo.pack(pady=10)

        self.tree = ttk.Treeview(self.master, columns=("ID", "Produto", "Descrição"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Produto", text="Produto")
        self.tree.heading("Descrição", text="Descrição")

        self.tree.column("ID", width=50)
        self.tree.column("Produto", width=150)
        self.tree.column("Descrição", width=200)

        self.tree.pack(pady=20)

        botao_adicionar = tk.Button(self.master, text="Adicionar Produto", command=self.adicionar_produto, bg="pink")
        botao_adicionar.pack(pady=5)

        botao_atualizar = tk.Button(self.master, text="Atualizar Produto", command=self.atualizar_produto, bg="pink")
        botao_atualizar.pack(pady=5)

    def adicionar_produto(self):
        nome_prod = simpledialog.askstring("Adicionar Produto", "Informe o nome do produto:")
        descricao = simpledialog.askstring("Adicionar Produto", "Informe a descrição do produto:")
        
        if not nome_prod or not descricao:
            messagebox.showwarning("Atenção", "Nome ou descrição inválidos.")
            return

        id_prod = len(self.produtos) + 1
        novo_produto = Produto(id_prod, nome_prod, descricao)
        self.produtos.append(novo_produto)
        self.tree.insert("", "end", values=(novo_produto.id_prod, novo_produto.nome_prod, novo_produto.descricao))
        messagebox.showinfo("Sucesso", f"Produto adicionado: {nome_prod}")

    def atualizar_produto(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showwarning("Atenção", "Selecione um produto para atualizar.")
            return
        
        item = self.tree.item(selected_item)
        produto_id = item['values'][0]
        
        nome_prod = simpledialog.askstring("Atualizar Produto", "Informe o novo nome do produto:", initialvalue=item['values'][1])
        descricao = simpledialog.askstring("Atualizar Produto", "Informe a nova descrição do produto:", initialvalue=item['values'][2])
        
        if not nome_prod or not descricao:
            messagebox.showwarning("Atenção", "Nome ou descrição inválidos.")
            return

        for produto in self.produtos:
            if produto.id_prod == produto_id:
                produto.nome_prod = nome_prod
                produto.descricao = descricao
                break
        
        self.carregar_produtos()
        messagebox.showinfo("Sucesso", "Produto atualizado com sucesso!")

if __name__ == "__main__":
    root = tk.Tk()
    app = ProdutosInterface(root)
    root.mainloop()

