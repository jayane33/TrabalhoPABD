import tkinter as tk
from tkinter import *
from tkinter import messagebox
from frontend.funcionario import FuncionarioInterface
from frontend.produtos import ProdutosInterface

class Aplication():
    def __init__(self):
        self.root = tk.Tk()
        self.tela()
        self.frame_tela()
        self.lacunatexto()
        self.root.mainloop()

    def tela(self): 
        texto = "Faça login agora!"
        label = tk.Label(text=texto, font=("Georgia", 16))
        label.pack(pady=20)

        func = tk.Button(text="Cadastrar funcionário!", bg="pink", command=self.abrir_funcionario_interface)
        produtos = tk.Button(text="Cadastrar produto", bg="lightpink", command=self.abrir_produtos_interface)
        func.place(x=10, y=10)
        produtos.place(x=10, y=50)

        self.root.configure(background='pink')
        self.root.geometry("700x500")
        self.root.resizable(True, True)
        self.root.maxsize(width=988, height=788)
        self.root.minsize(width=488, height=300)

    def frame_tela(self):
        self.frame1 = Frame(self.root, bd=4, highlightthickness=3)
        self.frame1.place(relx=0.02, rely=0.5, relwidth=0.96, relheight=0.46)

    def lacunatexto(self):
        self.entry_usuario = tk.Entry(self.frame1, width=40)
        self.entry_usuario.pack(pady=10)
        self.entry_usuario.insert(0, "Digite seu nome de usuário: ")

        self.entry_senha = tk.Entry(self.frame1, width=40, show='*')
        self.entry_senha.pack(pady=10)
        self.entry_senha.insert(0, "Digite sua senha: ")

        botao = tk.Button(self.frame1, text="Enviar", command=self.on_button_click)
        botao.pack()

    def on_button_click(self):
        usuario = self.entry_usuario.get()
        senha = self.entry_senha.get()
        if usuario == "admin" and senha == "senha123":  
            self.root.destroy()  
            self.abrir_funcionario_interface()
        else:
            messagebox.showwarning("Atenção", "Usuário ou senha incorretos.")

    def abrir_funcionario_interface(self):
        root = tk.Tk()
        app = FuncionarioInterface(root)
        root.mainloop()

    def abrir_produtos_interface(self):
        root = tk.Tk()
        app = ProdutosInterface(root)
        root.mainloop()

if __name__ == "__main__":
    app = Aplication()