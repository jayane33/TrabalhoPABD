class usuario:

    def __init__(self):
        self.username = None
        self.senha = None