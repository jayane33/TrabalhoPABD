class produto:

    def __init__(self):
        self.nome = None
        self.cargo = None