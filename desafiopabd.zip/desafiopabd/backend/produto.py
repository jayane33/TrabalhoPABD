class produto:

    def __init__(self):
        self.id_prod = None
        self.nome_prod = None
        self.descricacao = None