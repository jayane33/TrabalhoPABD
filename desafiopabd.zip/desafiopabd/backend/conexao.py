import psycopg2
from psycopg2 import sql

conn = psycopg2.connect(
    dbname='20231214010039',
    user='postgress',
    password='pabd',
    host='localhost',
    port='5432'
)

cursor = conn.cursor()

def createtable():

    comandos = [
        '''
        CREATE TABLE IF NOT EXISTS usuario (
            username VARCHAR(10) PRIMARY KEY,
            senhar VARCHAR(10)
        );
        ''',
        '''
        CREATE TABLE IF NOT EXISTS funcionario (
            nome VARCHAR(10) PRIMARY KEY,
            cargo VARCHAR(10)
        );
        ''',
        '''
        CREATE TABLE IF NOT EXISTS produto (
            id_prod SERIAL PRIMARY KEY,
            nome_prod VARCHAR(50),
            descricao VARCHAR(250)
        );
        '''
    ]
    
    for comando in comandos:
        cursor.execute(comando)

def inserir_dados():

    cursor.execute("INSERT INTO usuario (username, senhar) VALUES (%s, %s) ON CONFLICT (username) DO NOTHING", ('user1', 'senha1'))

    cursor.execute("INSERT INTO funcionario (nome, cargo) VALUES (%s, %s) ON CONFLICT (nome) DO NOTHING", ('Funcionário Exemplo', 'Cargo Exemplo'))

    cursor.execute("INSERT INTO produto (nome_prod, descricao) VALUES (%s, %s) RETURNING id_prod;", ('Produto Exemplo', 'Descrição do Produto Exemplo'))
    id_prod = cursor.fetchone()[0]

    cursor.execute("INSERT INTO pedido (username, id_prod) VALUES (%s, %s);", ('user1', id_prod))

try:
    createtable()
    inserir_dados()
    conn.commit()
except Exception as e:
    print(f"Ocorreu um erro: {e}")
finally:
    cursor.close()
    conn.close()